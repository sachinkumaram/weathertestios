//
//  WebserviceConfigUrl.swift
//  YahooWeatherSwift2
//
//  Created by Pratik Somaiya on 14/02/17.
//  Copyright © 2017 Pratik Somaiya. All rights reserved.
//

import Foundation
