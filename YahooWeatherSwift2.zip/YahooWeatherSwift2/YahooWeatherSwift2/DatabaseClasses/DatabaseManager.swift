//
//  DatabaseManager.swift
//  YahooWeatherSwift2
//
//  Created by Pratik Somaiya on 22/02/17.
//  Copyright © 2017 Pratik Somaiya. All rights reserved.
//

import Foundation
